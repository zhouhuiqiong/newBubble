<template>
	<div class="infinite-scroll-preloader">
        <div class="preloader"></div>
    </div>
</template>

